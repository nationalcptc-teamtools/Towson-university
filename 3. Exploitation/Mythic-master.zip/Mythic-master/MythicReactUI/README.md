# Getting Started with Create React App

This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).

## Available Scripts

In the project directory, you can run:

### `npm run react-build`

This builds the UI and outputs the files in the `/app/build` folder

### `npm run react-start`

This builds the UI and starts the internal server in development mode, so changes made to the code are reflected real-time in the UI