// @author: its_a_feature_
// This code is to administer Mythic 3.0.0+ configurations
package main

import (
	"github.com/MythicMeta/Mythic_CLI/cmd"
)

func main() {
	cmd.Execute()
}
