package config

// Constants and variables used by the Mythic CLI

var (
	// Version Mythic CLI version
	Version = "v0.2.1"
)
