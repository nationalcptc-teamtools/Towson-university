# Mythic_CLI
Golang code for the `mythic-cli` binary in Mythic. This binary provides control for various aspects of Mythic configuration.

## Compilation

Run `make` from the Mythic repo to automatically build the Linux binary and copy it into the Mythic directory.

